<style>
* {
    margin: 0px;
    padding: 0px;
    box-sizing: border-box;
}

.main_header_h5 {
    height: 50px;
    background-color: #f0569c;
}

.main_header_h5 h5 {
    color: white;
    font-weight: bold;
    text-align: center;
    padding-top: 10px;
}

.monthly-statement {
    height: 50px;

    border-bottom: 1px solid #fca2ca;
}

.monthly-statement h5 {
    padding-top: 15px;
    font-size: 15px;
}

.date_sd_bg_set {
    background-color: #f0569c;
    margin-left: 10px;
    font-size: 10px;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
}

.talent_gems {
    height: auto;
    border: 1px solid #fca2ca;
}

.talent_gems_1 {
    height: 60px;
    padding: 8px 10px;
    border: 1px solid #fca2ca;
}

.talent_gems_2 {
    height: 60px;
    padding: 8px 10px;
    border: 1px solid #fca2ca;
}

.talent_gems_3 {
    height: 60px;
    padding: 8px 10px;
    border: 1px solid #fca2ca;
}

.talent_gems_1 p {
    color: rgb(63, 63, 63);
    font-size: 15px;
}

.talent_gems_1 p::after {
    content: '';
    height: 2px;
    width: 15px;
    margin-left: 2px;

    background-color: #f0569c;
    display: block;
}

.talent_gems_2 p {
    color: rgb(63, 63, 63);
    font-size: 15px;
}

.talent_gems_2 p::after {
    content: '';
    height: 2px;
    width: 15px;
    margin-left: 2px;

    background-color: #f0569c;
    display: block;
}

.talent_gems_3 p {
    color: rgb(63, 63, 63);
    font-size: 15px;
}

.talent_gems_3 p::after {
    content: '';
    height: 2px;
    width: 15px;
    margin-left: 2px;

    background-color: #f0569c;
    display: block;
}

.talent_gems_3 h5 {
    color: rgb(63, 63, 63);
    font-size: 15px;
    font-weight: 500;

}

.talent_gems_3 h5::after {
    content: '418';
    height: 2px;
    width: 15px;
    margin-top: 5px;
    margin-left: 2px;
    display: block;
}

.agency_repor {
    padding: 10px;

}



.agency_report_right_btn {

    margin-top: 10px;
    border-radius: 4px;
    color: #f0569c;
    border: 1.5px solid #f0569c;
    background-color: transparent;
    transition: 0.2s;
}

.agency_report_right_btn:hover {
    box-shadow: 1px 1px 7px #f0569c;
}

.agency_report_right_btn {
    border: 2px solid #f0569c;
    padding: 5px 20px;
    color: white;
    cursor: pointer;
    position: relative;
    overflow: hidden;

    font-family: sans-serif;
    transition: all .5s;
}

.agency_report_right_btn:before {
    width: 100%;
    height: 100%;
    content: '';
    margin: auto;
    position: absolute;
    top: 0%;
    left: 0%;
    background: #f0569c;
    transition: all .5s;
    z-index: -1;

}

.agency_report_right_btn:after {
    width: 100%;
    height: 100%;
    content: '';
    margin: auto;
    position: absolute;
    top: 0%;
    left: 0%;
    background: #f0569c;
    transition: all .5s;
    z-index: -1;

}

.agency_report_right_btn:hover {
    color: #212121;
}

.agency_report_right_btn:hover:before {
    transform: rotateX(90deg);

}

.agency_report_right_btn:hover:after {
    transform: rotateY(90deg);

}

.current-img-space {
    height: 20px;
    background-color: #ececec;

}




p {
    padding-bottom: 10px;
    margin-top: 12px;

    margin-bottom: 1rem;
}

.btn.hover-filled-slide-right::before {
    top: 0;
    bottom: 0;
    right: 0;
    height: 100%;
    width: 100%;
}

.btn.hover-filled-slide-right:hover::before {
    width: 0%;
}


.current-month-left {
    height: 60px;
    padding: 8px 10px;
    border: 1px solid #fca2ca;
}

.current-month-right {
    height: 60px;
    padding: 8px 10px;
    border: 1px solid #fca2ca;
}

.current-month-left p {
    color: rgb(63, 63, 63);
    font-size: 15px;
}

.current-month-right p {
    color: rgb(63, 63, 63);
    font-size: 15px;
}

/* .current-month-left p::after {
    content: '0';
    height: 2px;
    width: 30px;
    margin-top: 1px;
    margin-left: 10px;
    display: block;
  }

  .current-month-right p::after {
    content: '0';
    height: 2px;
    width: 30px;
    margin-top: 1px;
    margin-left: 10px;
    display: block;
  } */

.talent_list h5 {
    font-size: 15px;
}

.search_talents_input {
    outline: none;
    width: 95%;
    border: none;
    margin-left: 10px;
    margin-top: 9px !important;
    background: none !important;
}

.andruni_search {
    width: 90%;
    height: 40px;
    overflow: hidden;
    border-radius: 100px;
    border: 2px solid #f0569c;
}

.andruni_search h2 {
    font-size: 15px;
    padding-top: 9px;
}

.date_sd_bg_india {
    background-color: #f0569c;
    margin-left: 10px;
    font-size: 10px;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
}

.accordion {
    outline: none !important;
}

.item_1 {
    font-size: 15px;
}

.accordion-button:focus {
    outline: none !important;

}

.accordion-body {
    border-top: 1px solid #f0569c;
    border-bottom: 1px solid #f0569c;

}

.rs_img {
    height: 50px;
    width: 50px;
    border-radius: 100%;
}

.actual_left {
    font-size: 15px;
    color: #212121;
    margin-left: 10px;
    font-weight: 600;
}

.actual_center {
    font-size: 15px;
    color: #212121;
    text-align: center;

}

.actual_right {
    font-size: 15px;
    color: #212121;
    text-align: right;

}

.center_top {
    margin-top: -40px;
}

.left_0 {
    margin-left: 60px;
}

.left_1 {
    margin-left: 60px;
    margin-top: -200px !important;
}



.btn:focus {
    box-shadow: none;
}

.dropbtn {

    padding: 16px;
    font-size: 16px;
    border: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

/* .dd-content { */
/* display: none; */
/* position: absolute; */
/* background-color: #f1f1f12a; */
/* width: 100%; */
/* box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); */
/* z-index: 1; */
/* } */
.dropdown:hover .dd-content {
    display: block;
}

.callist {
    list-style-type: none;
    line-height: 40px;
    text-align: center;
    height: 185px;
    overflow: auto;
    padding-left: 0px;
}

.year {
    line-height: 30px;
}

.day {
    line-height: 20px;
}

.item {
    padding: 5px;
}

.item:hover {
    background-color: #f1f1f1;


}

.callist::-webkit-scrollbar {
    display: none;
}

@media screen and (min-width: 320px) and (max-width: 520px) {
    .actual_right {
        text-align: center !important;
    }

    .left_1 p {
        text-align: center !important;
        border-bottom: 1px solid #fca2ca;
        padding-bottom: 20px;
    }

    .all_center {
        text-align: center !important;
        border-bottom: 1px solid #fca2ca;
        padding-bottom: 20px;
    }

    .search_talents_input {
        width: 85%;
    }

    .DurationForty p::after {
        /* float: right; */
        margin-left: 211px !important;
        margin-top: 5px !important;
    }

    .sixtyHCT p::after {
        margin-left: 211px !important;
        margin-top: 5px !important;
    }
}

@media screen and (min-width: 520px) and (max-width: 870px) {
    .search_talents_input {
        width: 90%;
    }

}

.nav-pills .nav-link.active,
.nav-pills .show>.nav-link {
    color: #f0569c;
    border-radius: 0px;
    background-color: white !important;
    border-bottom: 1px solid #f0569ced;
    transition: 1s;
}

ul .nav-item {
    padding-left: 20px;
}

th {
    border: 1px solid rgb(0, 0, 0);
    padding: 10px;
    color: #f162a3;
}

table td {
    border: 1px solid rgb(0, 0, 0);
}

td {
    padding: 5px;
}

.nav-link {
    color: black !important;
}

.btn-primary {
    color: #fff;
    margin-top: 10px !important;
    background-color: #f0569c;
    border-color: #ff02ef;
    outline: none !important;
}

.btn-primary:hover {
    background-color: transparent;
    border: 1px solid #f0569c;
    color: #f0569c;
}

.btn-check:focus+.btn-primary,
.btn-primary:focus {
    background-color: transparent;
    border: 1px solid #f0569c;
    color: #f0569c;
    box-shadow: none !important;
}

.van-cell {
    height: 30px;
    padding: 10px;
}

.DurationForty p::after {
    content: '<?php if (!empty($fortyH)) {echo $fortyH;} else {echo 0;} ?>';
    height: 2px;
    width: 15px;
    margin-top: 16px;
    margin-left: 395px;
    display: block;

}

.TalentCoin p::after {
    /* content: '<?php if (!empty($TalentCoin['monthlyCoins'])) {echo $TalentCoin['monthlyCoins'];} else {echo 0;} ?>'; */
    height: 2px;
    width: 15px;
    margin-top: -5px;
    margin-left: 225px;

    /* display: block; */
}

.liveDuration p::after {
    /* content: '<?php if (!empty($liveDuration)) {echo $liveDuration;} else {echo 0;} ?>'; */
    height: 2px;
    width: 15px;
    margin-top: -5px;
    margin-left: 225px;

    /* display: block; */
}

.activeTalents p::after {
    /* content: '<?php if (!empty($activeTalents)) {echo $activeTalents;} else {echo 0;} ?>'; */
    height: 2px;
    width: 15px;
    margin-top: -5px;
    margin-left: 225px;

    /* display: block; */
}

.totalTalents p::after {
    /* content: '<?php if (!empty($totalTalents)) {echo $totalTalents;} else {echo 0;} ?>'; */
    height: 2px;
    width: 15px;
    margin-top: -5px;
    margin-left: 225px;

    /* display: block; */
}

.totalCrown p::after {
    content: '<?php if (!empty($totalCrown)) {echo $totalCrown;} else {echo 0;} ?>';
    height: 2px;
    width: 15px;
    margin-top: -5px;
    margin-left: 225px;

    /* display: block; */
}

.TalentDiamond p::after {
    /* content: '<?php if (!empty($TalentDiamond)) {echo $TalentDiamond . " $";} else {echo 0 . " $";} ?>'; */
    height: 2px;
    width: 15px;
    margin-top: -5px;
    margin-left: 157px;

    /* display: block; */
}

.NewTalent p::after {
    /* content: ''; */
    height: 2px;
    width: 15px;
    margin-top: -5px;
    margin-left: 234px;

    /* display: block; */
}

.fortyHN p::after {
    content: '<?php if (!empty($fortyHN)) {echo $fortyHN;} else {echo 0;} ?>';
    height: 2px;
    width: 15px;
    margin-top: 5px;
    margin-left: 2px;
    display: block;
}

.sixtyHCT p::after {
    content: '<?php if (!empty($sixtyHCT)) {echo $sixtyHCT;} else {echo 0;} ?>';
    height: 2px;
    width: 15px;
    margin-top: 16px;
    margin-left: 395px;
    display: block;
}

.modal-dialog-2 {
    max-width: 100%;
    margin: 1.75rem auto;
}

th {
    padding-left: 30px;
    padding-bottom: 11px;
    border-bottom: 1px solid grey;
}

td {
    padding-left: 39px;
    padding-top: 10px;
}

.col-lg-4.col-md-4.col-sm-4.col-xs-4.NewTalent {
    border-bottom: 1px solid #f0569c;
}

.col-lg-4.col-md-4.col-sm-4.col-xs-4.activeTalents {
    border-bottom: 1px solid #f0569c;
}

.col-lg-4.col-md-4.col-sm-4.col-xs-4.totalTalents {
    border-bottom: 1px solid #f0569c;

}

.span_pdf {
    float: right;
}

.span_pdf button {
    background-color: #f0569c;
    color: white;
    padding: 5px 10px;
    border: none;
    border-radius: 4px;
}

button.btnExcel {
    /* float: right; */
    margin: 10px;
    padding: 10px 25px 10px 25px;
    background: #f162a3;
    color: white;
    border: none;
    /* transform: translate(1300px, 0px); */
    border-radius: 6px;
    font-weight: 600;
    text-transform: capitalize;
    font-size: 18px;
}

.col-lg-6.col-md-6.col-sm-6.DurationForty {
    border-bottom: 1px solid #f0569c;
}

.col-lg-6.col-md-6.col-sm-6.fortyHN {
    border-bottom: 1px solid #f0569c;
}

.col-lg-6.col-md-6.col-sm-6.sixtyHCT.p-2 {
    border-bottom: 1px solid #f0569c;
}
</style>
<div class="content-wrapper">
    <!-- <div class="container-fluid main_header_h5">
        <h5>Agency Code : <?=$agencyUser['agencyCode']?></h5>
    </div> -->
    <div class="container-fluid main_header_h5">
        <h5>Agency Portal</h5>
    </div>
    <div class="container-fluid">
        <div class="row monthly-statement">
            <h5><i class="fa-solid fa-calendar-days"></i> <span>Monthly Statement</span> <span
                    class="date_sd_bg_set"><?php echo $todayDateTime ?></span> <span class="span_pdf"><a
                        href="<?php echo site_url(); ?>/AgencyPanel/actionMT"><button>Monthly
                            Statement</button></a></span></h5>

        </div>
        <div class="row talent_gems">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 TalentCoin text-center">
                <p>Host Coin </p>
                <p><a class="btn"
                        href="<?php echo site_url(); ?>/AgencyPanel/agencyHosts/HostCoin"><?php if (!empty($TalentCoin['monthlyCoins'])) {echo $TalentCoin['monthlyCoins'] . " $";} else {echo 0 . " $";} ?></a>
                </p>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 TalentDiamond text-center">
                <p>Excellent Host Reward</p>
                <p><a class="btn"
                        href="<?php echo site_url(); ?>/AgencyPanel/agencyHosts/excellentHost"><?php if (!empty($HostExcellentReward)) {echo $HostExcellentReward . " $";} else {echo 0 . " $";} ?></a>
                </p>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 liveDuration text-center">
                <p>Live Duration</p>
                <p><a class="btn"
                        href="<?php echo site_url(); ?>/AgencyPanel/agencyHosts/liveDuration"><?php if (!empty($liveDuration)) {echo $liveDuration;} else {echo 0;} ?></a>
                </p>
            </div>
        </div>
        <!-- second -->
        <div class="row talent_gems">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 NewTalent text-center">
                <p>New Hosts</p>
                <p><a class="btn"
                        href="<?php echo site_url(); ?>/AgencyPanel/agencyHosts/NewHosts"><?php if (!empty($NewTalent)) {echo $NewTalent;} else {echo 0;} ?></a>
                </p>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 activeTalents text-center">
                <p>Active Hosts</p>
                <p><a class="btn"
                        href="<?php echo site_url(); ?>/AgencyPanel/agencyHosts/activeHosts"><?php if (!empty($activeTalents)) {echo $activeTalents;} else {echo 0;} ?></a>
                </p>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 totalTalents text-center">
                <p>Total Hosts</p>
                <p><a class="btn"
                        href="<?php echo site_url(); ?>/AgencyPanel/agencyHosts/TotalHosts"><?php if (!empty($totalTalents)) {echo $totalTalents;} else {echo 0;} ?></a>
                </p>
            </div>

        </div>

        <!-- next-button -->
        <div class="row agency_report mt-3">
            <div class="col-lg-12">
                <center>
                    <!-- <button class="agency_report_right_btn">Agency Report</button> -->
                    <button type="button" class="btn btn-primary agency_report_right_btn" data-bs-toggle="modal"
                        data-bs-target="#exampleModal-11">
                        Agency Report
                    </button>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal-11" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog modal-dialog-2">
                            <div class="modal-content">
                                <div class="modal-header d-flex">
                                    <h5 class="modal-title text-center" id="exampleModalLabel">Agency Report</h5>
                                    <a href="<?php echo site_url(); ?>/AgencyPanel/actionAgency"><button
                                            class="btnExcel">Agency Panel Excel</button></a>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <table>
                                        <tr>
                                            <th>Season Start</th>
                                            <th>Season End</th>
                                            <th>New Host</th>
                                            <th>Active Host</th>
                                            <th>Total Host</th>
                                            <th>Live Duration</th>
                                            <th>Agency Reward(💰)</th>
                                            <th>Host Coin Reward(💰)</th>
                                            <th>Excellent Host Reward(💰)</th>
                                            <th>Bonus(💰)</th>
                                        </tr>
                                        <tr>
                                            <td><?php echo $sesonStart ?></td>
                                            <td><?php echo $sesonExpire ?></td>
                                            <td><?php echo $NewTalent; ?></td>
                                            <td><?php echo $activeTalents ?></td>
                                            <td><?php echo $totalTalents ?></td>
                                            <td><?php echo $liveDuration;?></td>
                                            <td><?php echo $reward ?> $</td>
                                            <td><?php echo $hostsCoinReward ?> $</td>
                                            <td><?php echo $HostExcellentReward ?> $</td>
                                            <td><?php echo $extraReward ?> $</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="modal-footer">
                                    <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <button class="agency_report_right_btn">Revenue Export</button> -->
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#export">
                        Revenue Export
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="export" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">

                                    <div id="show">

                                    </div>
                                    <center>
                                        <div class="modal-content">


                                            <div class="container set_navtab_bottom_border mt-2">

                                                <ul class="nav nav-pills mb-3 add_set" id="pills-tab" role="tablist">
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link active" id="pills-home-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-home"
                                                            type="button" role="tab" aria-controls="pills-home"
                                                            aria-selected="true">Host Income</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link" id="pills-profile-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-profile"
                                                            type="button" role="tab" aria-controls="pills-profile"
                                                            aria-selected="false">Excellent Host Income</button>
                                                    </li>

                                                </ul>
                                                <div class="tab-content" id="pills-tabContent">
                                                    <div class="tab-pane fade active show" id="pills-home"
                                                        role="tabpanel" aria-labelledby="pills-home-tab">


                                                        <div class="container">
                                                            <table>
                                                                <thead>
                                                                    <tr>
                                                                        <th>Coins Requirment</th>
                                                                        <th>Coins Sharing($)</th>
                                                                        <th>Basic Salary($)</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php
                                                                    
                                                                    foreach($hostIncomeRequire as $list){ ?>

                                                                    <tr>

                                                                        <td><?=$list['coinsRequirement']?></td>
                                                                        <td><?=$list['coinSharing']?></td>
                                                                        <td><?=$list['basicSalary']?></td>

                                                                    </tr>

                                                                    <?php  }
                                                                    
                                                                    
                                                                    ?>


                                                                </tbody>
                                                            </table>
                                                        </div>


                                                    </div>
                                                    <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                                        aria-labelledby="pills-profile-tab">

                                                        <div class="container">
                                                            <table>
                                                                <thead>

                                                                    <th> Coins Requirment</th>
                                                                    <th> Reward($)</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>


                                                                    <?php
                                                                
                                                                foreach($excellentHostIncomeSheet as $hostList){ ?>

                                                                    <tr>

                                                                        <td><?=$hostList['requirments']?></td>
                                                                        <td><?=$hostList['reward']?></td>

                                                                    </tr>

                                                                    <?php }
                                                                
                                                                
                                                                ?>



                                                                </tbody>
                                                            </table>
                                                        </div>


                                                    </div>

                                                </div>



                                                <br>
                                            </div>


                                        </div>
                                    </center>

                                </div>
                            </div>
                        </div>
                    </div>



                </center>
            </div>
        </div>

        <!-- neww -->
        <div class="row mt-4">
            <div class="col-lg-12 current-img-space">

            </div>
        </div>
    </div>


    <!-- second-re-ready-start -->

    <div class="container-fluid">
        <div class="row monthly-statement">
            <h5><i class="fa-solid fa-calendar-check"></i> <span>Current Month Metrics</span> </h5>
        </div>
        <div class="row current-month">
            <div class="col-lg-6 col-md-6 col-sm-6 DurationForty text-center">
                <p>>40H Hosts</p>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 sixtyHCT p-2 text-center">
                <p>>60H Crown Hosts</p>
            </div>

        </div>

        <!-- second -->
        <div class="row current-month ">
            <!-- <div class="col-lg-6 col-md-6 col-sm-6 sixtyHCT p-2">
                <p>>60H Crown Talents</p>
            </div> -->

        </div>


        <!-- neww -->
        <div class="row mt-2">
            <div class="col-lg-12 current-img-space">

            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 talent_list p-3">
                <h5><i class="fa-solid fa-user-group"></i> Host List</h5>
            </div>
        </div>

        <!-- search-bar -->
        <div class="row">
            <div class="col-lg-12 search_talents p-2">
                <div class="row">
                    <center>
                        <div class="col-lg-12 col-md-12 col-sm-12 andruni_search">
                            <!-- <h2> -->
                            <div class="my-auto">
                                <i class="fa-solid fa-magnifying-glass"></i><input type="text" id="searchlist"
                                    class="search_talents_input" placeholder="Search Talents by TalentId">
                            </div>
                            <!-- </h2> -->
                        </div>
                    </center>
                </div>
            </div>
        </div>



    </div>
    <div class="showdata"></div>
    <div class="m-3"><a href="<?php echo site_url(); ?>/AgencyPanel/actionTL"><button class="btn btn-primary">Host
                List Excel</button></a></div>
    <div class="container-fluid accodian mt-4">
        <div class="row">
            <div class="accordion" id="accordionExample">
                <?php
          // echo "<pre>";
          // print_r($testdata);
          ?>
                <?php
            $i = 1;
            // print_r($talantList);exit;
            foreach ($talantList as $key => $lists) {
                // echo "<pre>";
                // print_r($lists);exit;
            ?>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne<?php echo $i; ?>">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseOne<?php echo $i; ?>" aria-expanded="false"
                            aria-controls="collapseOne<?php echo $i; ?>">
                            <h5 class="item_1">
                                <span><?php echo $lists['username'] ?>
                                    <?php echo $lists['userN'] ?></span>
                                <span class="date_sd_bg_india"><?php echo $lists['country'] ?></span>
                            </h5>
                        </button>
                    </h2>
                    <div id="collapseOne<?php echo $i; ?>" class="accordion-collapse collapse show"
                        aria-labelledby="headingOne<?php echo $i; ?>"
                        data-bs-parent="#accordionExample<?php echo $i; ?>">
                        <div class="accordion-body accordian1">
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-4">
                                    <p class="all_center">
                                        <span><img src="<?php echo $lists['image'] ?> " alt="" class="rs_img"></span>
                                        <span class="actual_left">Actual Earning</span>
                                        <br>
                                        <span class="left_0"><?php echo $lists['basicSalary'] ?></span>

                                    </p>

                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-4 mt-3">
                                    <h5 class="actual_center">Live Duration</h5>

                                    <span class="left_1">
                                        <p style="text-align: center; margin-top: -18px;">
                                            <?php echo round($lists['hoursLive']/60) ?></p>
                                    </span>


                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-4 mt-3">
                                    <h5 class="actual_right">Valid Days</h5>
                                    <span class="left_1">
                                        <p style="text-align: right; margin-top: -18px;">0h 0m</p>
                                    </span>
                                </div>
                            </div>

                            <center> <span class="modal_set_tab_accod">


                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal<?php echo $i; ?>">
                                        More Details
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal<?php echo $i; ?>" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">


                                                <div class="container set_navtab_bottom_border mt-2">

                                                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                                        <li class="nav-item" role="presentation">
                                                            <button class="nav-link" id="pills-home-tab"
                                                                data-bs-toggle="pill" data-bs-target="#pills-home"
                                                                type="button" role="tab" aria-controls="pills-home"
                                                                aria-selected="false">Home</button>
                                                        </li>
                                                        <li class="nav-item" role="presentation">
                                                            <button class="nav-link active" id="pills-profile-tab"
                                                                data-bs-toggle="pill" data-bs-target="#pills-profile"
                                                                type="button" role="tab" aria-controls="pills-profile"
                                                                aria-selected="true">Profile</button>
                                                        </li>
                                                        <li class="nav-item" role="presentation">
                                                            <button class="nav-link" id="pills-contact-tab"
                                                                data-bs-toggle="pill" data-bs-target="#pills-contact"
                                                                type="button" role="tab" aria-controls="pills-contact"
                                                                aria-selected="false">Contact</button>
                                                        </li>
                                                    </ul>
                                                    <div class="tab-content" id="pills-tabContent">
                                                        <div class="tab-pane fade" id="pills-home" role="tabpanel"
                                                            aria-labelledby="pills-home-tab">


                                                            <div class="container">
                                                                <div
                                                                    class="van-tabs__content van-tabs__content--animated">
                                                                    <div class="van-tabs__track"
                                                                        style="left: 0%; transition-duration: 0.3s;">
                                                                        <div class="van-tab__pane mt-4">
                                                                            <div class="van-cell">
                                                                                <div class="van-cell__title"><span
                                                                                        style="float: left;">Agency
                                                                                        Info</span></div>
                                                                                <div class="van-cell__value"
                                                                                    style="text-align: right; ">
                                                                                    <span><?php echo $lists['agencyDetail'] ?></span>
                                                                                </div>
                                                                            </div>
                                                                            <hr>
                                                                            <div class="van-cell">
                                                                                <div class="van-cell__title"><span
                                                                                        style="float: left;">Country</span>
                                                                                </div>
                                                                                <div class="van-cell__value"
                                                                                    style="text-align: right; ">
                                                                                    <span><?php echo $lists['country'] ?></span>
                                                                                </div>
                                                                            </div>
                                                                            <hr>
                                                                            <div class="van-cell">
                                                                                <div class="van-cell__title"><span
                                                                                        style="float: left;">Talent Join
                                                                                        Date</span></div>
                                                                                <div class="van-cell__value"
                                                                                    style="text-align: right; ">
                                                                                    <span><?php echo $lists['created'] ?></span>
                                                                                </div>
                                                                            </div>
                                                                            <hr>
                                                                            <div class="van-cell mt-3">
                                                                                <div class="van-cell__title"><span
                                                                                        style="float: left;">Last Login
                                                                                        Date</span></div>
                                                                                <div class="van-cell__value"
                                                                                    style="text-align: right; ">
                                                                                    <span>TO DO</span>
                                                                                </div>
                                                                            </div>
                                                                            <hr>
                                                                            <div class="van-cell">
                                                                                <div class="van-cell__title"><span
                                                                                        style="float: left;">Join Agency
                                                                                        Date</span></div>
                                                                                <div class="van-cell__value"
                                                                                    style="text-align: right; ">
                                                                                    <span><?php echo $lists['agencyJoin'] ?></span>
                                                                                </div>
                                                                            </div>
                                                                            <hr>
                                                                            <!-- <div class="van-cell">
                                                                                <div class="van-cell__title"><span
                                                                                        style="float: left;">Active</span>
                                                                                </div>
                                                                                <div class="van-cell__value"
                                                                                    style="text-align: right; ">
                                                                                    <span
                                                                                        style="margin-top: 30px ;">2020/05/13</span>
                                                                                </div>
                                                                            </div> -->
                                                                            <hr>
                                                                            <!---->
                                                                            <!---->
                                                                        </div>
                                                                        <div class="van-tab__pane">
                                                                            <!---->
                                                                        </div>
                                                                        <div class="van-tab__pane">
                                                                            <!---->
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>


                                                        </div>
                                                        <div class="tab-pane fade active show" id="pills-profile"
                                                            role="tabpanel" aria-labelledby="pills-profile-tab">

                                                            <div class="container">
                                                                <table>
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Month</th>
                                                                            <th>Gem Sharing</th>
                                                                            <th>Basic Salary($)</th>
                                                                            <th>Bonus($)</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>2022/06</td>
                                                                            <td>0</td>
                                                                            <td>-</td>
                                                                            <td>-</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/05</td>
                                                                            <td>0</td>
                                                                            <td>-</td>
                                                                            <td>-</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/04</td>
                                                                            <td>0</td>
                                                                            <td>-</td>
                                                                            <td>-</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/03</td>
                                                                            <td>0</td>
                                                                            <td>-</td>
                                                                            <td>-</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/02</td>
                                                                            <td>0</td>
                                                                            <td>-</td>
                                                                            <td>-</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/01</td>
                                                                            <td>0</td>
                                                                            <td>-</td>
                                                                            <td>-</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2021/12</td>
                                                                            <td>0</td>
                                                                            <td>-</td>
                                                                            <td>-</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>


                                                        </div>
                                                        <div class="tab-pane fade" id="pills-contact" role="tabpanel"
                                                            aria-labelledby="pills-contact-tab">
                                                            <div class="container">
                                                                <table>
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Month</th>
                                                                            <th>Actual Earning(💎)</th>
                                                                            <th>Live Duration</th>
                                                                            <th>Valid Days</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>2022/06</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/05</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/04</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/03</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/02</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2022/01</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>2021/12</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>



                                                    <br>
                                                </div>


                                            </div>
                                        </div>
                                    </div>

                                </span></center>
                        </div>
                    </div>
                </div>

                </ <?php
          $i++;
        }
        ?> </div>
            </div>
            <div class="text-center">Pages:- &nbsp;<?php echo $links; ?></div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js" type="text/javascript">
        </script>
        <link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/start/jquery-ui.css" rel="Stylesheet"
            type="text/css" />
        <script type="text/javascript">
        // $('#refresh').on('click', function(){
        //   location.reload(true);
        // });
        $('.profile-button').on('click', function() {
                var userId = $(this).data('id');
                // alert(userId);
                $.ajax({
                    method: "post",
                    url: "<?php echo site_url() ?>/AgencyPanel/profileDetails",
                    data: {
                        userId: userId
                    },
                    success: function(result) {
                        // alert(result);
                        // console.log(result);
                        // $('.gem').html(result);
                        // $('.date').html(result);
                        // history.go(0);
                        // location.reload(true);
                        $('.panipine').html(result);

                    }
                })
            }),

            $('.Contact-button').on('click', function() {
                var userId = $(this).data('id');
                // alert(userId);
                $.ajax({
                    method: "post",
                    url: "<?php echo site_url() ?>/AgencyPanel/contactDetails",
                    data: {
                        userId: userId
                    },
                    success: function(result) {
                        // alert(result);
                        $('.panipine1').html(result);

                    }
                })
            }),

            $('#searchlist').keyup(function() {
                var searchdata = $('#searchlist').val();
                // alert(searchdata);
                $.ajax({
                    method: "post",
                    url: "<?php echo site_url() ?>/AgencyPanel/serarchUserList",
                    data: {
                        searchdata: searchdata
                    },
                    success: function(data) {
                        $('.showdata').html(data);
                        //  alert(data);

                    }
                });
            });

        $("#searchDate").click(function() {
            var searchDate = $("#startdate").val();
            $.ajax({
                method: "post",
                url: "<?php echo site_url() ?>/AgencyPanel/searhAgencyPortalWithDate",
                data: {
                    searchDate: searchDate
                },
                //dataType: "json",                //data format
                success: function(result) {
                    $("#track").replaceWith(result);
                }
            });
        });

        $(function() {
            $("#startdate").datepicker({
                dateFormat: "yy/mm/dd",
                numberOfMonths: 1,
                maxDate: 0,
                onSelect: function(selected) {
                    var dt = new Date(selected);
                    dt.setDate(dt.getDate() + 1);
                    $("#enddate").datepicker("option", "minDate", dt);
                }
            });
            $("#enddate").datepicker({
                dateFormat: "yy/mm/dd",
                numberOfMonths: 1,
                maxDate: 0,
                onSelect: function(selected) {
                    var dt = new Date(selected);
                    dt.setDate(dt.getDate() - 1);
                    $("#startdate").datepicker("option", "maxDate", dt);
                }
            });
        });
        </script>
        <script>
        function wyear(em) {
            var a = document.getElementById(em.id);
            var year = parseInt(a.innerHTML);

            document.getElementById("year").innerHTML = year;

        }

        function wday(em) {
            var a = document.getElementById(em.id);
            var year = parseInt(a.innerHTML);

            document.getElementById("day").innerHTML = year;

        }

        function wmonth(em) {
            var a = document.getElementById(em.id);
            var year = a.innerHTML;

            document.getElementById("month").innerHTML = year;

        }
        </script>